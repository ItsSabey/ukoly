
package bezpecnost;

import java.util.Random;

public class ConvertToHex
{
 
   public String str()
    {
        Random random = new Random();
        int val = random.nextInt();
        String Hex = Integer.toHexString(val);

        return Hex.toString();
    }
}