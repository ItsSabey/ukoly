
package bezpecnost;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;

public class Generate
{
    public static void main(String[] args) throws NoSuchAlgorithmException, UnsupportedEncodingException
    {
        ConvertToHex conv = new ConvertToHex();
        ConvertSHA sha = new ConvertSHA();
        System.out.println(conv.str());
        System.out.println(sha.sha256());
    }
}
